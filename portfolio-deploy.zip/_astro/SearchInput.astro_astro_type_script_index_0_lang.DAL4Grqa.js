var Y=typeof global=="object"&&global&&global.Object===Object&&global,z=typeof self=="object"&&self&&self.Object===Object&&self,U=Y||z||Function("return this")(),I=U.Symbol,G=Object.prototype,J=G.hasOwnProperty,Q=G.toString,E=I?I.toStringTag:void 0;function V(e){var t=J.call(e,E),d=e[E];try{e[E]=void 0;var m=!0}catch{}var o=Q.call(e);return m&&(t?e[E]=d:delete e[E]),o}var Z=Object.prototype,ee=Z.toString;function te(e){return ee.call(e)}var ne="[object Null]",re="[object Undefined]",P=I?I.toStringTag:void 0;function ae(e){return e==null?e===void 0?re:ne:P&&P in Object(e)?V(e):te(e)}function ie(e){return e!=null&&typeof e=="object"}var se="[object Symbol]";function oe(e){return typeof e=="symbol"||ie(e)&&ae(e)==se}var ce=/\s/;function de(e){for(var t=e.length;t--&&ce.test(e.charAt(t)););return t}var le=/^\s+/;function ue(e){return e&&e.slice(0,de(e)+1).replace(le,"")}function A(e){var t=typeof e;return e!=null&&(t=="object"||t=="function")}var W=NaN,fe=/^[-+]0x[0-9a-f]+$/i,ge=/^0b[01]+$/i,me=/^0o[0-7]+$/i,he=parseInt;function q(e){if(typeof e=="number")return e;if(oe(e))return W;if(A(e)){var t=typeof e.valueOf=="function"?e.valueOf():e;e=A(t)?t+"":t}if(typeof e!="string")return e===0?e:+e;e=ue(e);var d=ge.test(e);return d||me.test(e)?he(e.slice(2),d?2:8):fe.test(e)?W:+e}var O=function(){return U.Date.now()},pe="Expected a function",ye=Math.max,ve=Math.min;function xe(e,t,d){var m,o,u,s,n,c,y=0,j=!1,h=!1,k=!0;if(typeof e!="function")throw new TypeError(pe);t=q(t)||0,A(d)&&(j=!!d.leading,h="maxWait"in d,u=h?ye(q(d.maxWait)||0,t):u,k="trailing"in d?!!d.trailing:k);function S(a){var v=m,T=o;return m=o=void 0,y=a,s=e.apply(T,v),s}function l(a){return y=a,n=setTimeout(w,t),j?S(a):s}function x(a){var v=a-c,T=a-y,F=t-v;return h?ve(F,u-T):F}function g(a){var v=a-c,T=a-y;return c===void 0||v>=t||v<0||h&&T>=u}function w(){var a=O();if(g(a))return B(a);n=setTimeout(w,x(a))}function B(a){return n=void 0,k&&m?S(a):(m=o=void 0,s)}function _(){n!==void 0&&clearTimeout(n),y=0,m=c=o=n=void 0}function X(){return n===void 0?s:B(O())}function $(){var a=O(),v=g(a);if(m=arguments,o=this,c=a,v){if(n===void 0)return l(c);if(h)return clearTimeout(n),n=setTimeout(w,t),S(c)}return n===void 0&&(n=setTimeout(w,t)),s}return $.cancel=_,$.flush=X,$}const be=(e,t)=>({handleSearch:xe(async o=>{const s=o.target.value.trim();if(s.length<2){t.classList.add("hidden"),e.setAttribute("aria-expanded","false");return}try{t.innerHTML=`
        <div class="p-4 text-sm text-gray-500 dark:text-gray-400">
          Searching...
        </div>
      `,t.classList.remove("hidden"),e.setAttribute("aria-expanded","true");const n=await fetch(`/api/search?q=${encodeURIComponent(s)}`),c=await n.json();if(!n.ok)throw new Error(c.error||"Search failed");const y=c.results,j=c.apology,h=c.suggestions,k=c.suggestionMessage;if(y.length===0){t.innerHTML=`
          <div class="p-4 text-sm text-gray-500 dark:text-gray-400">
            ${j||"Sorry, no results found."}
          </div>
          ${h&&h.length>0?`
            <div class="p-4">
              <div class="text-sm font-semibold text-gray-700 dark:text-gray-300 mb-2">
                ${k||"You might like..."}
              </div>
              <div class="divide-y divide-gray-100 dark:divide-text-primary">
                ${h.map(l=>`
                      <a
                        href="${l.url}"
                        class="block p-2 hover:bg-gray-50 dark:hover:bg-text-primary rounded-md transition-colors duration-150"
                        role="option"
                      >
                        <div class="font-medium text-gray-900 dark:text-gray-100">
                          ${l.title}
                        </div>
                        <div class="text-sm text-gray-500 dark:text-gray-400">
                          ${l.description}
                        </div>
                      </a>
                    `).join("")}
              </div>
            </div>
          `:""}
        `;return}const S=y.reduce((l,x)=>{const g=x.category;return l[g]||(l[g]=[]),l[g].push(x),l},{});t.innerHTML=`
        <div class="divide-y divide-gray-100 dark:divide-text-primary">
          ${Object.entries(S).map(([l,x])=>`
                <div class="p-2">
                  <h3 class="px-2 py-1 text-xs font-semibold text-gray-500 dark:text-gray-400 uppercase">
                    ${l}
                  </h3>
                  ${x.map(g=>`
                        <a
                          href="${g.url}"
                          class="block p-2 hover:bg-gray-50 dark:hover:bg-text-primary rounded-md transition-colors duration-150"
                          role="option"
                        >
                          <div class="font-medium text-gray-900 dark:text-gray-100">
                            ${g.title}
                          </div>
                          <div class="text-sm text-gray-500 dark:text-gray-400">
                            ${g.description}
                          </div>
                        </a>
                      `).join("")}
                </div>
              `).join("")}
        </div>
      `}catch(n){console.error("Search error:",n),t.innerHTML=`
        <div class="p-4 text-sm text-red-500 dark:text-red-400">
          An error occurred while searching. Please try again.
        </div>
      `}},300),handleKeyDown:o=>{const u=t.querySelectorAll("a"),s=Array.from(u).findIndex(n=>n.matches(":focus"));switch(o.key){case"ArrowDown":if(o.preventDefault(),s<u.length-1){const n=u[s+1];n&&n.focus()}break;case"ArrowUp":if(o.preventDefault(),s>0){const n=u[s-1];n&&n.focus()}break;case"Escape":t.classList.add("hidden"),e.setAttribute("aria-expanded","false"),e.blur();break}}});let r=null,p=null,b=null,i=null,f=null,L=!1;function D(){if(console.log("Attempting to expand search",{searchForm:!!i,searchInput:!!r,searchInputContainer:!!f}),!i||!r||!f){console.warn("Cannot expand search - missing elements");return}L=!0,i.classList.add("expanded"),f.classList.add("expanded"),r.focus(),console.log("Search expanded successfully")}function M(){if(console.log("Attempting to collapse search"),!i||!r||!p||!f){console.warn("Cannot collapse search - missing elements");return}L=!1,i.classList.remove("expanded"),f.classList.remove("expanded"),r.value="",p.classList.add("hidden"),r.setAttribute("aria-expanded","false"),console.log("Search collapsed successfully")}function C(e){e.preventDefault(),L?r&&r.value.trim()!==""?i&&i.submit():M():D()}function R(){if(L=!1,r=document.getElementById("search-input"),p=document.getElementById("search-results"),b=document.getElementById("search-toggle"),i=document.getElementById("search-form"),f=document.querySelector(".search-input-container"),!f&&i&&(f=i.querySelector(".search-input-container")),console.log("Setting up search with elements:",{searchInput:!!r,searchResults:!!p,searchToggle:!!b,searchForm:!!i,searchInputContainer:!!f}),b&&r&&i){if(b.removeEventListener("click",C),r.removeEventListener("focus",D),b.addEventListener("click",C),r.addEventListener("focus",D),r.removeEventListener("keydown",H),r.addEventListener("keydown",H),r&&p&&i){const{handleSearch:e,handleKeyDown:t}=be(r,p);r.removeEventListener("input",e),r.removeEventListener("keydown",t),r.addEventListener("input",e),r.addEventListener("keydown",t)}i.classList.contains("expanded")&&i.classList.remove("expanded"),f?.classList.contains("expanded")&&f.classList.remove("expanded"),p?.classList.contains("hidden")===!1&&p.classList.add("hidden"),console.log("Search setup complete")}else console.warn("Some search elements not found:",{searchToggle:!!b,searchInput:!!r,searchForm:!!i});Le()}function H(e){e.key}function Le(){document.removeEventListener("click",K),document.removeEventListener("keydown",N),document.addEventListener("click",K),document.addEventListener("keydown",N)}function K(e){const t=e.target;L&&t&&!i?.contains(t)&&!p?.contains(t)&&M()}function N(e){e.key==="Escape"&&L&&M()}document.addEventListener("DOMContentLoaded",()=>{setTimeout(R,10)});document.addEventListener("astro:page-load",()=>{setTimeout(R,10)});document.addEventListener("astro:after-swap",()=>{setTimeout(R,10)});
